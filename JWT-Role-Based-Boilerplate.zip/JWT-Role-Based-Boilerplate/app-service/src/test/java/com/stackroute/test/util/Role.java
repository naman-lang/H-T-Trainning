package com.stackroute.test.util;

public enum Role {
    ADMIN,
    USER
}
