package com.stackroute.service;

import com.stackroute.domain.Blog;

import com.stackroute.repository.BlogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @Service indicates annotated class is a service which hold business logic in the Service layer
 */
@Service
public class BlogServiceImpl implements BlogService {

    private BlogRepository blogRepository;

    /**
     * Constructor based Dependency injection to inject BlogRepository here
     */
    @Autowired
    public BlogServiceImpl(BlogRepository blogRepository) {
        this.blogRepository = blogRepository;
    }

    @Override
    public Blog saveBlog(Blog blog) {
        Blog blog1 = blogRepository.save(blog);
        return blog1;
    }

    @Override
    public List<Blog> getAllBlogs() {

        List<Blog> blogs = (List<Blog>) blogRepository.findAll();

        return blogs;
    }

    @Override
    public Blog getBlogById(int id) {
        Blog blog = blogRepository.findById(id).get();
        return blog;
    }

    @Override
    public Blog deleteBlog(int id) {
        Optional<Blog> blog= blogRepository.findById(id);
        if(blog.isEmpty()){
            return null;
        }
        blogRepository.deleteById(id);

        return blog.get();
    }

    @Override
    public Blog updateBlog(Blog blog) {
        Optional<Blog> blog2 = blogRepository.findById(blog.getBlogId());
        if(blog2.isEmpty()){
            return null;
        }
        return blogRepository.save(blog);
    }

    /**
     * save a new blog
     */

    /**
     * retrieve all blogs
     */


    /**
     * retrieve blog by id
     */

    /**
     * delete blog by id
     */

    /**
     * update blog
     */
}

