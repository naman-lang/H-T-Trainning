package com.stackroute.transactionsmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionsManagementApplication.class, args);
	}

}
