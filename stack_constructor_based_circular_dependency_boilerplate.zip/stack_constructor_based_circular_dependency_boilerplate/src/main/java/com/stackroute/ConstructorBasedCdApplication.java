package com.stackroute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConstructorBasedCdApplication {

	public static void main(String[] args) {

		SpringApplication.run(ConstructorBasedCdApplication.class, args);
	}

}
