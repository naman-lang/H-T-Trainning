package com.assgn3;

//Interface representing drawing capabilities
public interface Drawing {
 void drawShape(Shape shape);
}
