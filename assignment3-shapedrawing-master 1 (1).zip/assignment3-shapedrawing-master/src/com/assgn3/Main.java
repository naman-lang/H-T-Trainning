package com.assgn3;

public class Main {
    public static void main(String[] args) {
        // Dependency injection of specific shape (Circle in this case)
        Shape circle = new Circle();
        Drawing shapeDrawing = new ShapeDrawing(circle);

        // Drawing the circle without modifying existing code
        shapeDrawing.drawShape(circle);
    }
}
