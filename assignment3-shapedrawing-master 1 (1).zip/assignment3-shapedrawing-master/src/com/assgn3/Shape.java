package com.assgn3;

//Interface representing common properties and methods for all shapes
public interface Shape {
 void draw();
}
