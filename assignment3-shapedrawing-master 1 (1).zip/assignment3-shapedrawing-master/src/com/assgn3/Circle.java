package com.assgn3;

//Concrete class representing a Circle
public class Circle implements Shape {
 // Circle-specific properties and methods
 @Override
 public void draw() {
     // Implementation for drawing a circle
 }
}



