package com.assgn3;


// Concrete class implementing drawing capabilities
public class ShapeDrawing implements Drawing {
    // Dependency injection of Shape interface
    private Shape shape;

    public ShapeDrawing(Shape shape) {
        this.shape = shape;
    }

    @Override
    public void drawShape(Shape shape) {
        // Implementation for drawing any shape
        shape.draw();
    }
}
