package com.assgn3;

//Concrete class representing a Triangle
public class Triangle implements Shape {
 // Triangle-specific properties and methods
 @Override
 public void draw() {
     // Implementation for drawing a triangle
 }
}
