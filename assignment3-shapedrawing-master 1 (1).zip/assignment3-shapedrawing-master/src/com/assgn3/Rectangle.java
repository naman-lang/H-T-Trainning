package com.assgn3;

//Concrete class representing a Rectangle
public class Rectangle implements Shape {
 // Rectangle-specific properties and methods
 @Override
 public void draw() {
     // Implementation for drawing a rectangle
 }
}
