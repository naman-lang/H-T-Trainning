package com.stock.userprofile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserprofileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
