package com.stock.whishlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhishlistServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
