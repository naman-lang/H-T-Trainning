package com.stackroute.springdatajpamysql.entity;

import jakarta.persistence.Entity;

@Entity
public class Product {
    Long pid;
    Double Price;
    String Name;
	public Long getPid() {
		return pid;
	}
	public void setPid(Long pid) {
		this.pid = pid;
	}
	public Double getPrice() {
		return Price;
	}
	public void setPrice(Double price) {
		Price = price;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Product(Long pid ,String name, Double price) {
		super();
		this.pid = pid;
		Price = price;
		Name = name;
	}
   
	
    
	

}
