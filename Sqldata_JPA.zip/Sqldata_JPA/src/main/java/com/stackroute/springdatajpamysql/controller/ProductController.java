package com.stackroute.springdatajpamysql.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.service.ProductService;

public class ProductController {
    // Add controllers here for CRUD operations on Product entity.
	@Autowired
	ProductService productService;
	@GetMapping("GetAll")
	public ResponseEntity<List<Product>> getAllProducts(){
		return new ResponseEntity<>(productService.getAllProducts(),HttpStatus.OK);
	}
	@GetMapping("GetById/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable long productId){
		return new ResponseEntity<>(productService.getProductById(productId),HttpStatus.OK);
	}
	@PostMapping("add")
	public ResponseEntity<Product> saveProduct(@RequestBody Product product){
		return new ResponseEntity<>(productService.saveProduct(product),HttpStatus.OK);
	}
	@PutMapping("Update/{productId}")
	public ResponseEntity<Product> updateProduct(@RequestBody Product updatedProduct, @PathVariable long productId){
		return new ResponseEntity<>(productService.updateProduct(updatedProduct, productId),HttpStatus.OK);
	}
	@DeleteMapping("/delete/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable long productId){
		return new ResponseEntity<>(productService.deleteProduct(productId),HttpStatus.OK);
	}
	@GetMapping("getlessprice/{price}")
	public ResponseEntity<List<Product>> getAllProductsHavingPriceLessThan(@PathVariable double price){
		return new ResponseEntity<>(productService.getAllProductsHavingPriceLessThan(price),HttpStatus.OK);
		
	}

}
