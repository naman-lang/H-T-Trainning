package com.stackroute.springdatajpamysql.service;
import java.util.List;

import com.stackroute.springdatajpamysql.entity.Product;
//Create service interface here
public interface ProductService {
    //Add abstract methods here
	List<Product> getAllProducts();
	Product getProductById(long pid);
	Product saveProduct(Product p);
	Product updateProduct(Product updatedProduct, long productId);
	String deleteProduct(long productId);
	List<Product> getAllProductsHavingPriceLessThan(double price);
}
