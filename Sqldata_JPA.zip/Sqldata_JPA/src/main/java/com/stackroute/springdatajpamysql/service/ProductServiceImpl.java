package com.stackroute.springdatajpamysql.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepo productRepo;
	@Override
	public List<Product> getAllProducts() {
		List<Product> list = productRepo.findAll();
		return list;
	}

	@Override
	public Product getProductById(long pid) {
		Product p = productRepo.findById(pid).get();
		return p;
	}

	@Override
	public Product saveProduct(Product p) {
		Product product = productRepo.save(p);
		return product;
	}

	@Override
	public Product updateProduct(Product updatedProduct, long productId) {
		Product p = productRepo.findById(productId).get();
		p.setName(updatedProduct.getName());
		p.setPrice(updatedProduct.getPrice());
		p=productRepo.save(p);
		return p;
	}

	@Override
	public String deleteProduct(long productId) {
		productRepo.deleteById(productId);
		return "Product Deleted";
	}

	@Override
	public List<Product> getAllProductsHavingPriceLessThan(double price) {
		return productRepo.findProductsLessThanPrice(price);
	}
    //Override all the methods here
}
