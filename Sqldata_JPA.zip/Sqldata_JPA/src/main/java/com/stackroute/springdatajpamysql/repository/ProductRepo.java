package com.stackroute.springdatajpamysql.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.stackroute.springdatajpamysql.entity.Product;

//Create ProductRepo interface extending JpaRepository
public interface ProductRepo extends JpaRepository<Product, Long>{
	@Query("Select P from Product where p.productPrice< ?1")
	List<Product> findProductsLessThanPrice(double price);
	
}
