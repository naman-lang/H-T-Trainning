package Processor;

public class DebitCardPaymentProcessor implements PaymentProcessor{
    @Override
    public boolean processPayment(double amount) {
        System.out.println("Processing debit payment...");
        return true;
    }
}
