package Processor;

public interface PaymentProcessor {
    boolean processPayment(double amount);
}
