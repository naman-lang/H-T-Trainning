package Service;

import Entity.Product;

import java.util.List;

public interface ShippingService {

    void shipProducts(List<Product> products);
}
