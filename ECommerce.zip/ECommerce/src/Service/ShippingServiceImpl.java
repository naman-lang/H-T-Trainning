package Service;

import Entity.Product;

import java.util.List;

public class ShippingServiceImpl implements ShippingService{

    @Override
    public void shipProducts(List<Product> products){
        products.forEach(product-> System.out.println(product.getName()));
    }

}
