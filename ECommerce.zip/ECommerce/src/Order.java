import Entity.Product;
import Processor.PaymentProcessor;
import Service.ShippingService;
import Service.ShippingServiceImpl;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<Product> products = new ArrayList<>();
    private double totalAmount;

    public void addProduct(Product product){
        products.add(product);
        totalAmount+=product.getPrice();
    }

    public void checkout(PaymentProcessor paymentProcessor){
        if (paymentProcessor.processPayment(totalAmount)){
            ShippingService shippingService = new ShippingServiceImpl();
            shippingService.shipProducts(products);
            System.out.println("Order processed successfully");
        } else {
            System.out.println("Payment failed. Order not processed.");
        }
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
